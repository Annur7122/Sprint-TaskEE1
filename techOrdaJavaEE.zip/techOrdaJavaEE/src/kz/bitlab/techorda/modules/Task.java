package kz.bitlab.techorda.modules;

public class Task {
    private int ID;
    private String description, deadline, name;
    private Boolean status = false;

    public Task() {}

    public Task(String name, String description, String deadline) {
        this.deadline = deadline; this.name = name;
        this.description = description;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return new String(ID + " " + name + " " + description + " " + deadline + " " + status);
    }
}
