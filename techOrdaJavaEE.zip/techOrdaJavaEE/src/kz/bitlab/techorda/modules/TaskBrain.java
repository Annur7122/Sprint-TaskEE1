package kz.bitlab.techorda.modules;

import java.util.TreeMap;

public class TaskBrain {
    private static TreeMap<Integer, Task> tasks = new TreeMap<>();
    private static int id = 0;

    static {
        Task task = new Task();
        task.setName("Gym");
        task.setDeadline("2021-09-01");
        task.setDescription("Go to the gym");

        addTask(task);

        task = new Task();
        task.setName("Study");
        task.setDeadline("2021-09-01");
        task.setDescription("Study for the exam");

        addTask(task);

        task = new Task();
        task.setName("Work");
        task.setDeadline("2021-09-01");
        task.setDescription("Work on the project");

        addTask(task);
    }

    public static void addTask(Task task) {
        task.setID(id);
        tasks.put(id, task);
        id++;
    }

    public static TreeMap<Integer, Task> getTasks() {
        return tasks;
    }

    public static void removeTask(int ID) {
        tasks.remove(ID);
    }

}