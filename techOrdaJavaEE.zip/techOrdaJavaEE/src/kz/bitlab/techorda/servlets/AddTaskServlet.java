package kz.bitlab.techorda.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import kz.bitlab.techorda.modules.Task;
import kz.bitlab.techorda.modules.TaskBrain;

import java.io.IOException;

@WebServlet(value = "/add-task")
public class AddTaskServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Task task = new Task();

        String taskName = req.getParameter("task-name");
        String taskDescription = req.getParameter("task-description");
        String taskDeadline = req.getParameter("task-deadline");
        String taskStatus = req.getParameter("task-status");

        task.setName(taskName);
        task.setDeadline(taskDeadline);
        task.setDescription(taskDescription);
        task.setStatus(taskStatus.equals("1"));

        TaskBrain.addTask(task);

        resp.sendRedirect("/home");
    }
}
